cordova.define('cordova/plugin_list', function(require, exports, module) {
  module.exports = [
    {
      "id": "cordova-plugin-zohodesk-portal.CordovaZohoDeskPortal",
      "file": "plugins/cordova-plugin-zohodesk-portal/www/CordovaZohoDeskPortal.js",
      "pluginId": "cordova-plugin-zohodesk-portal",
      "clobbers": [
        "cordova.plugins.CordovaZohoDeskPortal"
      ]
    }
  ];
  module.exports.metadata = {
    "cordova-plugin-whitelist": "1.3.4",
    "cordova-plugin-zohodesk-portal": "0.1.0"
  };
});